<?php
// $servername = "sql12.freesqldatabase.com";
// $username = "sql12601583";
// $password = "z6jiJTrM6S";
// $dbname = "sql12601583";

// $servername = "db5007637702.hosting-data.io";
// $username = "dbu959277";
// $password = "GnkEDsNcLtOxadCKKMyf";
// $dbname = "dbs6309051";

// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "employee";

  $host_name = 'https://avalon.herosite.pro/';
  $database = 'ictdzfbe_yashpal';
  $user_name = 'ictdzfbe_Yashpal';
  $password = 'ictdzfbe_Yashpal';

  $conn = new mysqli($host_name, $user_name, $password, $database);

  if ($conn->connect_error) {
    die('<p>Failed to connect to MySQL:- '. $conn->connect_error .'</p>');
  } else {
    echo '<p>Connection to MySQL server successfully established.</p>';
  }
?> 