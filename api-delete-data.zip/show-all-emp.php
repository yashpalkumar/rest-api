<?
php echo "Hi Dear...";



?>